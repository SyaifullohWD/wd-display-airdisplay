# Pocket AirDisplay

Android secondary-display receiver for macOS Screen Mirroring, derived from
[Wormhole Display](https://github.com/pgodlews/wormhole-display) (GPLv3) with
security fixes and general-phone adaptation.

> **Honest status — read this first.**
> Audited-fix default version: **0.1.1-dev / code 2**. Publication requires the
> full JVM/native/protocol/DNS/validator gates, 16 KiB ELF and ZIP alignment,
> SDK zipalign and APK signature verification. A published release is host-gated,
> not proof of macOS interoperability. Authorized Galaxy A55 installation,
> cold Activity/service startup and six isolated lifecycle regression classes
> passed; interactive notification allow/deny recovery remains unverified.
> Exact hashes, failed intermediate attempts and raw logs are recorded in
> `evidence/FIX-INTEGRATION-RESULT.md` (evidence is not bundled).
> macOS **picker**, **extended desktop**, **hotspot**, **hardware video decode**
> and **continuous runtime** remain **UNTESTED**.

## Intended AirPlay behavior (interoperability gates UNTESTED)

- Appear in the native macOS Screen Mirroring picker (no companion app on the Mac)
- Support mirror and extended desktop (sender chooses in macOS Displays settings)
- H.264 (and H.265 where the phone's MediaCodec supports it) hardware decode
- Foreground receiver lifecycle with a SurfaceView for the mirrored frame
- Same-LAN or phone-hotspot topology (mDNS does not cross NAT; no AWDL/p2p)
- Legacy RAOP/AirTunes audio path is **excluded**: no RSA private key in the
  tree, ANNOUNCE is rejected unconditionally (501)

## Requirements

- Android 10+ (API 29), arm64 — `minSdk = 29`, because the prebuilt
  `libcrypto.a`/`libplist-2.0.a` in this tree were compiled with
  `__ANDROID_API__=29`. Older Android 9 (API 28) devices are **not** claimed.
- macOS with Control Center → Screen Mirroring (the sender)
- Shared Wi-Fi network or phone hotspot that both devices join

## Build (actual commands and paths used in this repo)

### Toolchain actually used

- JDK: Android Studio JBR — `/Applications/Android Studio.app/Contents/jbr/Contents/Home`
- Android SDK: **project-local** `.tools/sdk` (pinned via `local.properties`
  `sdk.dir=.tools/sdk`), Build Tools 36.0.0, platform android-36
- NDK: **project-local** `.tools/ndk-r27d` (NDK 27.3.13750724 / r27d).
  `app/build.gradle.kts` points `ndkPath` at it when the directory exists, so
  AGP never auto-downloads an NDK into the global SDK.

To provision the NDK from the official Google repository (only if
`.tools/ndk-r27d` is missing):

```bash
# Source: https://dl.google.com/android/repository/android-ndk-r27d-darwin.zip
# SHA1:   2970926d705988f79baa9b04c51b4f7914dd8c56
mkdir -p tools .tools
curl -L "https://dl.google.com/android/repository/android-ndk-r27d-darwin.zip" \
     -o tools/android-ndk-r27d-darwin.zip
shasum tools/android-ndk-r27d-darwin.zip   # verify against SHA1 above
unzip tools/android-ndk-r27d-darwin.zip -d .tools/
mv .tools/android-ndk-r27d .tools/ndk-r27d
```

The NDK ends up at **repo-root** `.tools/ndk-r27d/` — that is where every
script and the Gradle config expect it.

### Debug APK

```bash
export JAVA_HOME="/Applications/Android Studio.app/Contents/jbr/Contents/Home"
export ANDROID_HOME="$PWD/.tools/sdk"
export ANDROID_NDK_HOME="$PWD/.tools/ndk-r27d"
./gradlew --no-build-cache clean :app:assembleDebug :app:testDebugUnitTest
# APK: app/build/outputs/apk/debug/app-debug.apk
```

Or the convenience script (same environment variables):

```bash
./scripts/build.sh
# → deliverables/pocket-airdisplay-debug.apk
```

### 16 KiB alignment regression gate (October 19, 2026)

NDK r27d is explicitly configured with
`-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON` through Gradle CMake arguments,
as documented in the official NDK r27 changelog. No native protocol code changed.
The previous APK failed all three `libpocketairdisplay.so` PT_LOAD checks.
The corrected APK passes every PT_LOAD in both packaged ELF libraries (six
segments total) and ZIP alignment. This is static artifact proof, not proof of
runtime behavior on a 16 KiB-page device.

```bash
python3 -B tests/test_apk_alignment.py -v
python3 -B scripts/verify-apk-alignment.py deliverables/pocket-airdisplay-debug.apk
.tools/sdk/build-tools/36.0.0/zipalign -c -P 16 -v 4 deliverables/pocket-airdisplay-debug.apk
.tools/sdk/build-tools/36.0.0/apksigner verify --verbose --print-certs deliverables/pocket-airdisplay-debug.apk
```

The verifier checks **every** ELF PT_LOAD, including ELF entries outside `.so`
paths, and checks 16 KiB ZIP data offsets for stored `.so` entries (4-byte
alignment for other stored entries). Compressed ELF entries still receive ELF
checks. `scripts/build.sh` runs this gate before coherent staged publication.
Nine deterministic format-fixture tests cover later-segment regressions, 32-bit
ELF, compressed entries, bad ZIP offsets, and malformed/missing ELF. Detailed
red/green logs and exact argument arrays are `evidence/build/alignment-*`.
Exact current APK and corresponding-source SHA256: `deliverables/SHA256SUMS`.
Resolve the `deliverables` release once when reading multiple files; previous
releases remain under `.delivery-releases`. Failed gates retain prior publication.

### Android unit tests

```bash
./gradlew --no-build-cache :app:testDebugUnitTest
# JVM queue/telemetry/identity/history/display/lifecycle/resource regressions
```

Test sources live at `app/src/test/java/org/pocketairdisplay/receiver/` — the
same package (`org.pocketairdisplay.receiver`) as the app code they exercise, so
directory and package agree.

### Native host tests (no Android device required)

```bash
./scripts/test-native.sh
# mirror parser regression (50 cases) + DMAP parser, UBSan — logs to
# evidence/build/native-tests.log

./scripts/test-native-audit.sh
# Mandatory production-linked ASan/UBSan: streaming AES, fragmented request,
# HTTP prefixes 0..7, valid/deadline/backpressure and production 10 s deadline,
# active rekey, real DNS boundaries/invalid registration, JNI UTF-8 byte budget.

./scripts/test-core-protocol.sh
# unity-builds the real raop.c/handlers/http/dnssd under ASan+UBSan against the
# host libplist + libcrypto, then runs 40 production-handler assertions
# (ANNOUNCE rejection, OPTIONS Public, SETUP malformed root/type/eiv/ekey
# rejections, /info statusFlags, real mDNS TXT record construction).
# Evidence: evidence/build/core-protocol-test.{argv,stdout,stderr,meta,compile.log,host-deps}
```

`test-core-protocol.sh` does **not** invoke any package manager (no `brew`).
It only reads existing prefixes; override them if needed:

```bash
PLIST_PREFIX=/path/to/libplist OPENSSL_PREFIX=/path/to/openssl@3 ./scripts/test-core-protocol.sh
# defaults: /opt/homebrew/opt/libplist and /opt/homebrew/opt/openssl@3
# actual host dependency versions are recorded in
# evidence/build/core-protocol-test.host-deps — nothing is ever installed
```

### Native dependency rebuild (optional — already-built archives are committed)

```bash
./scripts/build-deps.sh
# rebuilds libcrypto (OpenSSL 3.0.16) and libplist 2.6.0 for android-arm64,
# api=29, using .tools/ndk-r27d.
# Source tarball SHA256 pins are verified BEFORE extraction and a mismatch
# aborts the build; make-install failure is never ignored (only the documented
# ranlib repair path runs, and the outputs are then validated).
# Provenance: tools/build-deps-provenance.txt
```

## Installation (manual sideload — not Play Store)

```bash
adb -s "$AUTHORIZED_SERIAL" install -r deliverables/pocket-airdisplay-debug.apk
adb -s "$AUTHORIZED_SERIAL" shell am start -n org.pocketairdisplay.receiver/.MainActivity
```

> **Device operations require device-owner consent.** The parent operator owns
> installation and physical acceptance. See the separate integration evidence for
> actual install/startup results. No automatic permission grants, data wiping,
> overlay/security/network changes or captures are needed. Debug-signed only.

## Usage (intended flow — UNTESTED on hardware)

1. Install and launch Pocket AirDisplay on the Android phone.
2. Respond to the notification permission prompt yourself. Overlay access is
   optional user opt-in for auto-foreground; without it, tap the notification.
   Denied notifications do not prevent foreground receiver startup, but limit
   background incoming-stream recovery.
3. On the Mac, open Control Center → Screen Mirroring.
4. Select **Pocket AirDisplay** (or the configured service name).
5. For extended display: connect first, then macOS System Settings → Displays →
   "Use as extended display". The Mac controls mirror vs. extended.

## Known limitations and honest test status

| Area | Status |
|---|---|
| macOS picker visibility (mDNS `/info` + RAOP/AirPlay records) | Host-asserted on generated records only — **UNTESTED on hardware** |
| Extended desktop (extension mode) | **UNTESTED** (upstream donor tested Meta Portal hardware only) |
| Hotspot / same-subnet operation | **UNTESTED** (depends on phone multicast forwarding) |
| Video decode/render path (MediaCodec/SurfaceView) | **UNTESTED** on a device; only JVM-level queue/telemetry tests run |
| Continuous 60-minute session | **UNTESTED** |
| Galaxy A55 startup/service/lifecycle | Separate authorized device evidence: `evidence/FIX-INTEGRATION-RESULT.md`; not Mac interoperability acceptance |
| Legacy RAOP/AirTunes audio | Intentionally excluded (no RSA key material; ANNOUNCE → 501) |
| macOS Music audio-only (FairPlay SAP v2.5) | Not supported; no open implementation exists |
| Android 9 (API 28) | **Not supported/claimed** — prebuilt deps are API 29 |

## Scope and licensing

Derived from Wormhole Display (GPLv3) with targeted changes:

- Package: `org.pocketairdisplay.receiver`, label: Pocket AirDisplay
- Legacy RSA private key (`rsakey.c`) physically excluded; inert NULL-safe stub used
- Unconditional ANNOUNCE/RAOP rejection (no legacy audio state mutation)
- Bounded plist `eiv`/`ekey` length validation (16 and 72 bytes exactly)
- Malformed SETUP roots (missing body, non-dict root, wrong-typed
  `ekey`/`eiv`/`streams`, nothing-to-set-up) rejected instead of answered with a
  successful empty response
- Negotiated session key material removed from debug logs
- RAOP mDNS TXT `et`/`ek`/`cn` reflect excluded capabilities; advertised
  `flags` reconciled with `/info` `statusFlags` (0x44)
- `minSdk` 29 to match the API level the prebuilt dependencies were compiled with

License: GPLv3. See `LICENSE` and `THIRD_PARTY_NOTICES.md`.
`THIRD_PARTY_NOTICES.md` covers all three component groups: the vendored native
components (UxPlay core, llhttp, mdnsd, OpenSSL 3.0.16, libplist 2.6.0), the
Maven/JVM dependencies shipped in the APK (AndroidX/Compose and Kotlin, pinned at
their resolved versions; Apache-2.0, plus test-only JUnit 4.13.2 / EPL-1.0), and
the UxPlay vendor-patch inventory with the deliberately excluded legacy
RSA/RAOP-audio patches.
Source obligations: provide full source on distribution per GPLv3 §6 —
`deliverables/pocket-airdisplay-source.tar.gz` is the sanitized source bundle
(it excludes `references/`, `tools/` archives other than the pinned dependency
source tarballs, `.tools/`, build outputs, caches, evidence/session logs, and
any signing material; it includes notices, build scripts, tests, the pinned
OpenSSL/libplist source tarballs for relinking, and the static `.a` object
material). Rebuild it with `./scripts/package-source.sh`, which applies an
explicit include list and refuses to package private-key material or excluded
paths.

## Evidence and audit

- `evidence/SCOPE-AUDIT.md` — Gate 0 technical scope review (FairPlay SAP vs. DRM)
- `evidence/REVIEW-NOTES.md`, `evidence/REVIEW-CONTINUATION.md` — reviewer findings
- `evidence/IMPLEMENTATION-RESULT.md` — completed vs. blockers, commands/logs,
  APK hash, exact next acceptance steps
- `evidence/build/` — raw argv/stdout/stderr/exit logs for Gradle and host tests.
  Current-source (review round 2) logs: `gradle-review2.*`,
  `review2-native-tests.*`, `review2-core-protocol.*`, `package-source.log`,
  `maven-deps-{runtime,test,resolved}.log`, `review2-bundle-members.txt`.
- `deliverables/` — APK, `SHA256SUMS`, sanitized source archive
- `scripts/package-source.sh` — rebuilds the sanitized corresponding-source
  bundle and `SHA256SUMS` from an explicit include list (guards: excluded paths,
  private-key markers)
